//
//  Problem.swift
//  Quiz
//
//  Created by 長谷部龍太 on 2020/06/10.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit

class Problem: UIViewController {
    
    //問題文
    var question = String()
    //答え（「○」なら「0」、「×」なら「1」）
    var answer = Int()
    
    //問題文と答えを格納
    func setQ(q: String, a: Int){
        question = q
        answer = a
    }
    
    //問題文を読み出し
    func getQ() -> String {
        return question
    }
    //答えを読み出し
    func getA() -> Int {
        return answer
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
