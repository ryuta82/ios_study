//
//  ViewController.swift
//  Quiz
//
//  Created by 長谷部龍太 on 2020/06/09.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBAction func backView(segue: UIStoryboardSegue) {
            
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

