//
//  ViewController.swift
//  Counter
//
//  Created by 長谷部龍太 on 2020/06/04.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var countLabel: UILabel!
    
    //合計を管理する「変数」
    var count = Int()
    //ラベル用の文字列を管理する「インスタンス」
    var countLabelText = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //起動時にcountを0に初期化する。
        count = 0
    }

    
    //プラスボタンが押された時
    @IBAction func plusPushed(_ sender: Any) {
        //countに1を加算
        count += 1
        
        if count >= 0 && count < 10 {
            countLabel.textColor = UIColor.black
        } else if count >= 10 && count < 20 {
            countLabel.textColor = UIColor.green
        } else if count >= 20 && count < 30 {
            countLabel.textColor = UIColor.yellow
        } else {
            countLabel.textColor = UIColor.red
        }
        
        //ラベル用に文字列を用意
        countLabelText = "\(count)"
        //counyLabelの値を更新
        countLabel.text = countLabelText
    }
    
    
    //マイナスボタンが押された時
    @IBAction func minusPushed(_ sender: Any) {
        if count > 0 {
            count -= 1
        }
        if count >= 0 && count < 10 {
            countLabel.textColor = UIColor.black
        } else if count >= 10 && count < 20 {
            countLabel.textColor = UIColor.green
        } else if count >= 20 && count < 30 {
            countLabel.textColor = UIColor.yellow
        } else {
            countLabel.textColor = UIColor.red
        }
        countLabelText = "\(count)"
        countLabel.text = countLabelText
    }
    
    
    //リセットボタンが押された時
    @IBAction func resetPushed(_ sender: Any) {
        count = 0
        countLabel.textColor = UIColor.black
        countLabelText = "\(count)"
        countLabel.text = countLabelText
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

