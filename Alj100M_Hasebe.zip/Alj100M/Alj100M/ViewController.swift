//
//  ViewController.swift
//  Alj100M
//
//  Created by 長谷部龍太 on 2020/06/12.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func backView(segue:UIStoryboardSegue){
    }

}

