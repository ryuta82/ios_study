//
//  UserRegisterViewController.swift
//  FuelEconomy
//
//  Created by 長谷部龍太 on 2020/06/25.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit
import NCMB

class UserRegisterViewController: UIViewController {
    
    @IBOutlet weak var userIdTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func userRegisterButtonTapped(sender: AnyObject){
        //NCMBユーザーインスタンス生成(NCMBにユーザを作成)
        let user = NCMBUser()
        user.userName = self.userIdTextField.text
        user.password = self.passwordTextField.text
        //ACL設定(全員を読み込み可能とする)   ACL（アクセス権限）
        let acl = NCMBACL()
        acl.setPublicReadAccess(true)
        user.acl = acl
        
        //ユーザ登録
        user.signUpInBackground({(error) in
            if(error != nil){
                print("ユーザー登録失敗:\(String(describing: error))")
            }else{
                print("ユーザ登録完了")
                // アラート通知
                let aleat = UIAlertController(title: "登録完了", message: "ユーザ登録完了しました。", preferredStyle: .alert)
                aleat.addAction(UIAlertAction(
                    title: "OK",
                    style: .default,
                    handler: {(action:UIAlertAction) -> Void in
                        self.navigationController?.popToRootViewController(animated: true)
                }))
                self.present(aleat, animated: true, completion: nil)
            }
        })
    }

}
