//
//  ViewController.swift
//  FuelEconomy
//
//  Created by 長谷部龍太 on 2020/06/25.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit
import NCMB

class ViewController: UIViewController {

    @IBOutlet weak var amountTextField:     UITextField!
    @IBOutlet weak var odometerTextField:   UITextField!
    @IBOutlet weak var priceTextField:      UITextField!
    @IBOutlet weak var resultEcoLabel:      UILabel!
    @IBOutlet weak var resultPriLabel:      UILabel!
    
    var amount      = Double()
    var odometer    = Double()
    var price       = Double()
    var resultEco   = Double()
    var resultPri   = Double()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        amount      = 0
        odometer    = 0
        price       = 0
        resultEco   = 0
        resultPri   = 0
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //ログインチェック
        self.loginCheck()
    }
    
    
    func loginCheck() {
        if(NCMBUser.current() != nil) {
            print("ログイン済み")
        } else {
            print("未ログイン")
            //ログイン画面
            self.performSegue(withIdentifier: "toLogin", sender: nil)
        }
    }
    
    @IBAction func logoutButtonTapped(sender: AnyObject) {
        NCMBUser.logOut()
        //loginCheckの実行
        self.loginCheck()
    }
    
    
    
    //▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼//
    
    @IBAction func resultButton(sender: UIButton) {
        
        //燃費を計算して出力
        amount = atof(amountTextField.text!)
        odometer = atof(odometerTextField.text!)
        resultEco = odometer / amount
        resultEcoLabel.text = String(format: "%.0f", resultEco)
        
        //ガソリン代(円/L)を計算して出力
        price = atof(priceTextField.text!)
        resultPri = price / amount
        resultPriLabel.text = String(format: "%0f", resultPri)
        
    }
    
    
    @IBAction func saveButton(sender: UIButton){
        
        let result = NCMBObject(className: "result")
        result?.setObject(NCMBUser.current(), forKey: "owner")
        result?.setObject(resultEco, forKey: "resultEco")
        result?.setObject(resultPri, forKey: "resultPri")
        result?.saveInBackground({(error)in
            if (error != nil) {
                print("保存失敗：\(String(describing: error))")
            }else{
                print("保存成功")
                let alert = UIAlertController(
                    title:"保存完了",
                    message:"データを保存しました。",
                    preferredStyle: .alert
                )
                let action = UIAlertAction(
                    title: "OK", style: .default, handler: {(action:UIAlertAction) -> Void in
                        self.navigationController?.popToRootViewController(animated: true)
                })
                alert.addAction(action)
                self.present(alert, animated: true, completion: nil)
            }
        })

        
    }
    

}

