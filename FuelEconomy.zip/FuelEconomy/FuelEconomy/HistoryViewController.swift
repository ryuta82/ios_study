//
//  HistoryViewController.swift
//  FuelEconomy
//
//  Created by 長谷部龍太 on 2020/06/26.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit
import NCMB

class HistoryViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var history = NSArray()
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        fetchHistory()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return history.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let user = history.object(at: indexPath.row) as! NCMBUser
        cell.textLabel!.text = user.userName
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user = history.object(at: indexPath.row) as! NCMBUser
        self.performSegue(withIdentifier: "toUserDetail", sender: user)
    }
    
    
    //Hsitoryを取得して表示する。
    func fetchHistory() {
        let history = NCMBQuery(className: "result")
        
        history?.whereKey("objectId", notEqualTo: NCMBUser.current()?.objectId)
        history?.findObjectsInBackground({(objects, error) in
            if (error != nil){
                print("取得失敗:\(String(describing: error))")
            }else{
                print("取得成功")
                self.history = objects! as NSArray
                self.tableView.reloadData()
            }
        })
    }
}
