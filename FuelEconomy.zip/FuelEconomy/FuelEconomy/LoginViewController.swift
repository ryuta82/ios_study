//
//  LoginViewController.swift
//  FuelEconomy
//
//  Created by 長谷部龍太 on 2020/06/25.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var userIdTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func loginButtonTapped(sender: AnyObject){
        let userId = userIdTextField.text!
        let password = passwordTextField.text!
        NCMBUser.logInWithUsername(inBackground: userId, password: password, block: ({(user: NCMBUser!, error:
            Error!) in
            if (error != nil){
                print("ログイン失敗:\(String(describing: error))")
            }else{
                print("ログイン成功:\(String(describing: user))")
                //トップ画面へ戻る
                self.navigationController?.popToRootViewController(animated: true)
            }
        }))
    }
}
