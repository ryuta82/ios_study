//
//  StampSelectViewController.swift
//  StampCamera
//
//  Created by 長谷部龍太 on 2020/06/17.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit

//UICollectionViewDataSource:コレクションビューの数を設定
//UICollectionViewDelegate:コレクションビューの中のセルが選択または編集されたときに呼び出されるメソッドが定義
class StampSelectViewController: UIViewController ,UICollectionViewDataSource, UICollectionViewDelegate{

    //画像を格納する配列
    var imageArray:[UIImage] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //配列imageArrayに1~6.pngの画像データを格納
        for i in 1...6 {    //for 変数 in 初期値...終了値
            imageArray.append(UIImage(named: "\(i).png")!)
        }
    }
    
    
    //スタンプ選択画面を閉じるメソッド
      @IBAction func closeTapped() {
          //モーダルで表示した画面を閉じる
          self.dismiss(animated: true, completion: nil)
      }

    
    //コレクションビューのアイテム数を設定
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //戻り値にimageArrayの要素数を設定
        return imageArray.count
    }
    
    //コレクションビューのセルを設定
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath)-> UICollectionViewCell {
        //UICollectionViewCellを使うための変数を作成
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath as IndexPath)
        //セルの中の画像を表示するImageViewのタグを指定
        let imageView = cell.viewWithTag(1) as! UIImageView ///セルの中のImageViewに配列の中の画像データを表示(IndexPathはコレクションビューの配列番号)
        imageView.image = imageArray[indexPath.row]
        return cell
    }

}
