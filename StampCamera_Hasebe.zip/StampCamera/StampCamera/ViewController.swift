//
//  ViewController.swift
//  StampCamera
//
//  Created by 長谷部龍太 on 2020/06/16.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIActionSheetDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var pickerController = UIImagePickerController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //UIImagePickerControllerのデリゲート(委譲)メソッドを使用する設定
        pickerController.delegate = self
    }
    
    
    //UIImagePickerControllerで取得した画像を表示
    @IBOutlet var mainImageView:UIImageView!
    
    //UIImagePickerController画像取得メソッド
    private func imagePickerController(_ imagePicker: UIImagePickerController, didFinishPickingMediaWithInfo info:[String : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage.rawValue] as? UIImage {
            mainImageView.image = pickedImage
        }
        //閉じる処理
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
    //アクションシート表示メソッド
    @IBAction func cameraTapped() {
        //UIActionSheet生成
        let actionSheet:UIAlertController = UIAlertController(title:"写真を取得",
                                                              message:"写真の取得先を選択してください",
                                                              preferredStyle: UIAlertController.Style.actionSheet)
        
        //Cancelボタン
        let cancelAction:UIAlertAction = UIAlertAction(title: "Cancel",
                                                       style: UIAlertAction.Style.cancel,
                                                       handler: {
                                                        (action: UIAlertAction!) -> Void in
                                                        print("Cancel")
        })
        
        //Cameraボタン
        let cameraAction:UIAlertAction = UIAlertAction(title: "Camera",
                                                        style: UIAlertAction.Style.default,
                                                        handler: {
                                                            (action: UIAlertAction!) -> Void in
                                                            print("Camera")
                                                            //1番目のボタンを押したらソースタイプをカメラに
                                                            self.pickerController.sourceType = UIImagePickerController.SourceType.camera
                                                            //UIImagePickerControllerを表示
                                                            self.present(self.pickerController, animated: true, completion:  nil)
        })
        
        //Libraryボタン
        let libraryAction:UIAlertAction = UIAlertAction(title: "Library",
                                                        style: UIAlertAction.Style.default,
                                                        handler: {
                                                            (action:UIAlertAction!) -> Void in
                                                            print("Libray")
                                                            //2番目のボタンを押したらソースタイプをフォトライブラリに設定
                                                            self.pickerController.sourceType = UIImagePickerController.SourceType.photoLibrary
                                                            self.present(self.pickerController, animated: true, completion: nil)
        })
        
        
        //AlertViewControolerにボタンを追加
        actionSheet.addAction(cancelAction)
        actionSheet.addAction(cameraAction)
        actionSheet.addAction(libraryAction)
        //画面表示
        present(actionSheet, animated: true, completion: nil)
    }

    
    //スタンプ選択画面遷移メソッド
    @IBAction func stampTapped() {
        //SegueのIdentifierを設定
        self.performSegue(withIdentifier: "ToStampList", sender: self)
    }

    
}

