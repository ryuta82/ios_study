//
//  ViewController.swift
//  ClapBeat
//
//  Created by 長谷部龍太 on 2020/06/08.
//  Copyright © 2020 ALJ. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    //PickerViewの列の数を指定
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        //カラム(拍手の回数のみ)
        return 1
    }
    
    //カラムの要素数を指定
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //10個の要素(1~10)
        return 10
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int,forComponent compoent: Int) -> String? {
        return repeatNumbersForPicker[row] as? String
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        repeatCount = row + 1
    }

    @IBOutlet weak var PickerView: UIPickerView?
    //clapを初期化
    let clapInstance = Clap()
    //NSMutableArray版
    var repeatNumbersForPicker = NSMutableArray()
    //Array版
    var repeatNumbersArray: [String] = []
    //ユーザーに選択された回数を格納。
    var repeatCount = Int()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Picker Viewの選択肢の一覧を準備
            for i in 0 ..< 10 {
                let numberText = String(format: "%d回", i+1)
                //NSMutableArray版
                repeatNumbersForPicker[i] = numberText
                // Array版
                repeatNumbersArray.append(numberText)
            }
               
            PickerView?.delegate = self
            PickerView?.dataSource = self
        }
    
    @IBAction func play(sender: AnyObject){
        //Clapクラスの中のメソッドを呼び出し、指定回数分再生
        clapInstance.repeatClap(count: repeatCount)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        //初期の手拍子の数として1（1回）を指定
        repeatCount = 1

    }
}
